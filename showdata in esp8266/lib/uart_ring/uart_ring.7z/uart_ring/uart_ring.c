#include "uart_ring.h"

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
/**/
static callBackFun_EventTypedef ringBuffCmpCmd( 
#ifndef RING_USE_ARR
    cmdNodeTypedef * cmdNodeP
#else
    int cmdIndex
#endif
    );
static callBackFun_EventTypedef intFlagJudge(
#ifndef RING_USE_ARR
    ringNodeTypedef *ringNodeP, cmdNodeTypedef *cmdNodeP,
#else
    int ringNodeP, int cmdIndex, 
#endif
    int index);
static callBackFun_EventTypedef floatFlagJudge(
#ifndef RING_USE_ARR
    ringNodeTypedef *ringNodeP, cmdNodeTypedef *cmdNodeP,
#else
    int ringNodeP, int cmdIndex, 
#endif
    int index);

/*----------RING BUFF FUN----------*/
#ifndef RING_USE_ARR
    static ringNodeTypedef *ringHeadP, *ringTailP;  
#else
    static uint8_ring ringBuffArr[RING_BUFF_LENGTH];
    static int ringBuffHead = 0, ringBuffTail = 0;
#endif

void ringBuff_Init(void){
#ifndef RING_USE_ARR
    ringHeadP = NULL;
    ringTailP = ringHeadP;
#else
    ringBuffHead = 0;
    ringBuffTail = ringBuffHead - 1;
#endif
}

void ringBuff_Push(uint8_ring data){
#ifndef RING_USE_ARR
    if(ringHeadP == NULL){
        ringHeadP = (ringNodeTypedef*)malloc(sizeof(ringNodeTypedef));
        ringTailP = ringHeadP;
    }
    else{
        ringTailP->next = (ringNodeTypedef*)malloc(sizeof(ringNodeTypedef));
        ringTailP = ringTailP->next;
    }
    ringTailP->data = data;
	ringTailP->next = NULL;
#else
    ringBuffTail = (ringBuffTail + 1)%RING_BUFF_LENGTH;
    ringBuffArr[ringBuffTail] = data;
#endif
}

ring_state ringShowBuff( char ringBuffStr[RING_BUFF_LENGTH]){
#ifndef RING_USE_ARR
    ringNodeTypedef *tmpP = ringHeadP;
    if(tmpP == NULL)
#else
    if(ringBuffHead == (ringBuffTail + 1)%RING_BUFF_LENGTH)
#endif
    {
        sprintf(ringBuffStr,"");
        return RING_WAIT;
    }
#ifndef RING_USE_ARR
    for (int i = 0; i < RING_BUFF_LENGTH; i++){
        ringBuffStr[i] = tmpP->data;
        if(tmpP->next == NULL){
            if(i != RING_BUFF_LENGTH - 1)
                ringBuffStr[i+1] = 0;
            return RING_OK;
        }
        tmpP = tmpP->next;
    }
#else
    int tmp = ringBuffHead - ringBuffTail;
    if(tmp < 0) tmp += RING_BUFF_LENGTH;
    for (int i = 0; i < tmp + 1; i++){
        ringBuffStr[i] = ringBuffArr[(i + ringBuffHead)%RING_BUFF_LENGTH];
    }
#endif
    return RING_ERR;
}

static ring_state ringBuff_FreeHeadP(void){
#ifndef RING_USE_ARR
    if(ringHeadP == NULL) return RING_ERR;
    ringNodeTypedef *tmpP = ringHeadP;
    ringHeadP = ringHeadP->next;
    free(tmpP);
#else
    if(ringBuffHead == (ringBuffTail + 1)%RING_BUFF_LENGTH) return RING_WAIT;
    ringBuffHead = (ringBuffHead + 1)%RING_BUFF_LENGTH;
#endif
    return RING_OK;
}

/*----------CMD Fun----------*/
#ifndef RING_USE_ARR
    static cmdNodeTypedef *cmdHeadP,*cmdTailP;
#else
    static cmdNodeTypedef cmdBuffArr[CMD_BUFF_LENGTH];
    static int cmdBuffLength = 0;
#endif

void cmdBuff_Init(void){
#ifndef RING_USE_ARR
    cmdHeadP = NULL;
    cmdTailP = cmdHeadP;
#else
    cmdBuffLength = 0;
#endif
}

ring_state cmdBuff_Push( uint8_ring cmd_String[CMD_STRING_LENGTH], void (*callBackFn)(callBackFun_EventTypedef e)){
    if(strcmp("",cmd_String) == 0) return RING_ERR;
#ifndef RING_USE_ARR
    if(cmdHeadP != NULL){
        cmdNodeTypedef *tmpP = cmdHeadP;
        while (1){
            if(strcmp(tmpP->cmd_String,cmd_String) == 0)
                return RING_ERR;
            if(tmpP->next == NULL)
                break;
			tmpP = tmpP->next;
        }
    }
    if(cmdHeadP == NULL){
        cmdHeadP = (cmdNodeTypedef*)malloc(sizeof(cmdNodeTypedef));
        cmdTailP = cmdHeadP;
    }
    else{
        cmdTailP->next = (cmdNodeTypedef*)malloc(sizeof(cmdNodeTypedef));
        cmdTailP = cmdTailP->next;
    }
    sprintf(cmdTailP->cmd_String,cmd_String);
    cmdTailP->callBackFn = callBackFn;
    cmdTailP->next = NULL;
#else
    if(cmdBuffLength != 0){
        for (int i = 0; i < cmdBuffLength; i++)
        {
            if(strcmp(cmdBuffArr[i].cmd_String,cmd_String) == 0)
                return RING_ERR;
            if(i == CMD_BUFF_LENGTH - 1)
                return RING_BUFF_OVERFLOW;
        }
    }
    sprintf(cmdBuffArr[cmdBuffLength].cmd_String,cmd_String);
    cmdBuffArr[cmdBuffLength].callBackFn = callBackFn;
    cmdBuffLength++;
#endif
    return RING_OK;
}

ring_state cmdBuff_DelCmd( uint8_ring cmd_String[CMD_STRING_LENGTH]){
#ifndef RING_USE_ARR
    cmdNodeTypedef *tmpP = cmdHeadP, *preNode;
    while(1){
        if(strcmp(cmdHeadP->cmd_String,cmd_String) == 0){
            if(tmpP == cmdHeadP)
                cmdHeadP = NULL;
            else
                preNode->next = tmpP->next;
            free(tmpP);
            return RING_OK;
        }
        else if( tmpP->next == NULL)
            return RING_ERR;
        else{
            preNode = tmpP;
            tmpP = tmpP->next;
        }
    }
#else
    int index = 0;
    if(cmdBuffLength == 0) return RING_WAIT;
    for (int i = 0; i < cmdBuffLength; i++)
    {
        if(strcmp(cmdBuffArr[i].cmd_String,cmd_String) == 0){
            index = i;
            cmdBuffLength--;
            for(int i = index;i < cmdBuffLength; i++){
                cmdBuffArr[i] = cmdBuffArr[i + 1];
            }
            return RING_OK;
        }
    }
    return RING_ERR;
#endif
}

/*----------CMP CMD AND CALL CALLBACK FUN----------*/

static int ringERRcnt = 0;
ring_state ringBuffHandleFun(void){
#ifndef RING_USE_ARR
    cmdNodeTypedef *tmp_cmdP = cmdHeadP;
    if(tmp_cmdP == NULL) return RING_ERR;
    if(ringHeadP == NULL) return RING_WAIT;
#else
    if(cmdBuffLength == 0)
        return RING_ERR;
    if(ringBuffHead == (ringBuffTail + 1)%RING_BUFF_LENGTH)
        return RING_WAIT;
    int tmp_cmdP = 0;
#endif
    callBackFun_EventTypedef e;
    ringERRcnt = 0;
    while (1){
        e = ringBuffCmpCmd( tmp_cmdP);
        switch (e.state)
        {
        case RING_ERR:
#ifndef RING_USE_ARR
            if(tmp_cmdP->next == NULL)
#else
            if(tmp_cmdP == cmdBuffLength - 1)
#endif
            {
                ringBuff_FreeHeadP();
                return RING_FREEHEAD;
            }
#ifndef RING_USE_ARR
            else tmp_cmdP = tmp_cmdP->next;
#else
            else tmp_cmdP++;
#endif
            break;

        case RING_WAIT:
            return RING_WAIT;
            break;

        case RING_WAITFORFLAG:
            return RING_WAITFORFLAG;
            break;

        case RING_OK:
        case RING_INT:
        case RING_FLOAT:
            for( int i = 0;i<e.offset;i++)
                ringBuff_FreeHeadP();
#ifndef RING_USE_ARR
            tmp_cmdP->callBackFn(e);
#else
            cmdBuffArr[tmp_cmdP].callBackFn(e);
#endif
            break;

        default:
            return RING_ERR;
            break;
        }
    }
}

static callBackFun_EventTypedef ringBuffCmpCmd( 
#ifndef RING_USE_ARR
    cmdNodeTypedef * cmdNodeP
#else
    int cmdIndex
#endif
    ){
#ifndef RING_USE_ARR
    ringNodeTypedef *tmp_ringP = ringHeadP;
    cmdNodeTypedef *tmp_cmdP = cmdNodeP;
#else
    int tmp_ringP = ringBuffHead;
#endif
    callBackFun_EventTypedef event;
    int isDelRingHeadP = 0;
    for(
        int i =0;i<CMD_STRING_LENGTH;i++
        ){
#ifndef RING_USE_ARR
        if(tmp_cmdP->cmd_String[i] == 0)
#else
        if(cmdBuffArr[cmdIndex].cmd_String[i] == 0)
#endif
        {
			switch (event.state) {
			case RING_INT:
				event.offset = event.offset - 4 + i;
				break;
			case RING_FLOAT:
				event.offset = event.offset - 6 + i;
				break;
			default:
				event.state = RING_OK;
				event.offset = i;
				break;
			}
            return event;
        }
#ifndef RING_USE_ARR
        if(tmp_ringP->data == tmp_cmdP->cmd_String[i])
#else
        if(cmdBuffArr[cmdIndex].cmd_String[i] == ringBuffArr[tmp_ringP])
#endif
        {
            isDelRingHeadP++;
#ifndef RING_USE_ARR
            event = intFlagJudge( tmp_ringP, tmp_cmdP, i);
#else
            event = intFlagJudge( tmp_ringP, cmdIndex, i);
#endif
            if( event.state == RING_ERR ){
                return event;
            }
            else if( event.state == RING_WAIT || event.state == RING_WAITFORFLAG){
#ifndef RING_USE_ARR
                if(tmp_cmdP->cmd_String[i + 1] == 0)
#else
                if(cmdBuffArr[cmdIndex].cmd_String[i + 1] == 0)
#endif
                {
                    event.state = RING_OK;
				    event.offset = i;
					return event;
                }
#ifndef RING_USE_ARR
				if(tmp_ringP->next == NULL || event.state == RING_WAITFORFLAG)
					return event;
				tmp_ringP = tmp_ringP->next;
#else
                if(tmp_ringP == ringBuffTail || event.state == RING_WAITFORFLAG)
					return event;
                tmp_ringP = (tmp_ringP + 1)%RING_BUFF_LENGTH;
#endif
                continue;
            }
            else if( event.state == RING_INT || event.state == RING_FLOAT){
				if(event.state == RING_INT)
					i = i + 4;
				else if(event.state == RING_FLOAT)
					i = i + 6;
                for (int tmp_i = 0; tmp_i < event.offset; tmp_i++)
#ifndef RING_USE_ARR
                    tmp_ringP = tmp_ringP->next;
				if(tmp_ringP->next == NULL) 
#else
                    tmp_ringP = (tmp_ringP+1)%RING_BUFF_LENGTH;
                if(tmp_ringP == (ringBuffTail + 1)%RING_BUFF_LENGTH)
#endif
                    return event;
            }
        }
#ifndef RING_USE_ARR
        else if(tmp_ringP->data != tmp_cmdP->cmd_String[i])
#else
        else if(cmdBuffArr[cmdIndex].cmd_String[i] != ringBuffArr[tmp_ringP])
#endif
        {
            event.state = RING_ERR;
            return event;
            break;
        }
    }
    // if(isDelRingHeadP == 0)
    // else
    event.state = RING_WAIT;
    return event;
}

static callBackFun_EventTypedef intFlagJudge(
#ifndef RING_USE_ARR
    ringNodeTypedef *ringNodeP, cmdNodeTypedef *cmdNodeP,
#else
    int ringNodeP, int cmdIndex, 
#endif
    int index){
    callBackFun_EventTypedef event;
#ifndef RING_USE_ARR
    if(cmdNodeP->cmd_String[index] != '{'){
        event.state = RING_WAIT;
        return event;
    }
    if(cmdNodeP->cmd_String[index + 1] == INT_FLAG[1] &&
        cmdNodeP->cmd_String[index + 2] == INT_FLAG[2] &&
        cmdNodeP->cmd_String[index + 3] == INT_FLAG[3] &&
        cmdNodeP->cmd_String[index + 4] == INT_FLAG[4]
        )
#else
    if(cmdBuffArr[cmdIndex].cmd_String[index] != '{'){
        event.state = RING_WAIT;
        return event;
    }
    if(cmdBuffArr[cmdIndex].cmd_String[index + 1] == INT_FLAG[1] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 2] == INT_FLAG[2] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 3] == INT_FLAG[3] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 4] == INT_FLAG[4]
        )
#endif
        {
        int cnt = 0;
#ifndef RING_USE_ARR
        if(ringNodeP->next == NULL)
#else
        if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
        {
            event.state = RING_WAITFORFLAG;
            return event;
        }
#ifndef RING_USE_ARR
        ringNodeTypedef *tmp_ringP = ringNodeP->next;
#else
        ringNodeP = (ringNodeP + 1)%RING_BUFF_LENGTH;
#endif
        int arrBuff[CMD_STRING_LENGTH];
        for (int i = 0;i<CMD_STRING_LENGTH; i++){
#ifndef RING_USE_ARR
            uint8_ring data = tmp_ringP->data;
#else
            uint8_ring data = ringBuffArr[ringNodeP];
#endif
            if('0' <= data && data <= '9'){
                arrBuff[i] = data - '0';
#ifndef RING_USE_ARR
                if(tmp_ringP->next == NULL)
#else
                if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
                {
                    event.state = RING_WAITFORFLAG;
                    return event;
                }
#ifndef RING_USE_ARR
				tmp_ringP = tmp_ringP->next;
#else
                ringNodeP++;
#endif
            }
            else if(data == '}'){
                cnt = i;
                event.state = RING_INT;
                event.offset = cnt;
                break;
            }
            else{
#ifndef RING_USE_ARR
                if(tmp_ringP->next == NULL)
#else
                if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
                {
                    event.state = RING_WAITFORFLAG;
                    return event;
                }
                event.state = RING_ERR;//cmp next cmd
                return event;
            }
        }
        event.intData = 0;
        int tmp = 1;
        for (int i = 0; i < cnt; i++){
            event.intData += arrBuff[cnt - i - 1]*tmp;
            tmp *= 10;
        }
        return event;
    }
    else
#ifndef RING_USE_ARR
        return floatFlagJudge( ringNodeP, cmdNodeP, index);
#else
        return floatFlagJudge( ringNodeP, cmdIndex, index);
#endif
}


static callBackFun_EventTypedef floatFlagJudge(
#ifndef RING_USE_ARR
    ringNodeTypedef *ringNodeP, cmdNodeTypedef *cmdNodeP,
#else
    int ringNodeP, int cmdIndex, 
#endif
    int index
    ){
    callBackFun_EventTypedef event;
#ifndef RING_USE_ARR
    if(cmdNodeP->cmd_String[index] != '{'){
        event.state = RING_WAIT;
        return event;
    }
    if(cmdNodeP->cmd_String[index + 1] ==  FLOAT_FLAG[1] &&
        cmdNodeP->cmd_String[index + 2] == FLOAT_FLAG[2] &&
        cmdNodeP->cmd_String[index + 3] == FLOAT_FLAG[3] &&
        cmdNodeP->cmd_String[index + 4] == FLOAT_FLAG[4] &&
        cmdNodeP->cmd_String[index + 5] == FLOAT_FLAG[5] &&
        cmdNodeP->cmd_String[index + 6] == FLOAT_FLAG[6]
        )
#else
    if(cmdBuffArr[cmdIndex].cmd_String[index] != '{'){
        event.state = RING_WAIT;
        return event;
    }
    if( cmdBuffArr[cmdIndex].cmd_String[index + 1] ==  FLOAT_FLAG[1] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 2] == FLOAT_FLAG[2] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 3] == FLOAT_FLAG[3] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 4] == FLOAT_FLAG[4] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 5] == FLOAT_FLAG[5] &&
        cmdBuffArr[cmdIndex].cmd_String[index + 6] == FLOAT_FLAG[6]
        )
#endif
        {
        int cnt = 0;
#ifndef RING_USE_ARR
        if(ringNodeP->next == NULL)
#else
        if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
        {
            event.state = RING_WAITFORFLAG;
            return event;
        }
#ifndef RING_USE_ARR
        ringNodeTypedef *tmp_ringP = ringNodeP->next;
#else
        ringNodeP = (ringNodeP + 1)%RING_BUFF_LENGTH;
#endif
        char strBuff[CMD_STRING_LENGTH];
        for (int i = 0;i<CMD_STRING_LENGTH; i++){
#ifndef RING_USE_ARR
            uint8_ring data = tmp_ringP->data;
#else
            uint8_ring data = ringBuffArr[ringNodeP];
#endif
            if('0' <= data && data <= '9' || data == '.'){
                strBuff[i] = data;
#ifndef RING_USE_ARR
                if(tmp_ringP->next == NULL)
#else
                if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
                {
                    event.state = RING_WAITFORFLAG;
                    return event;
                }
#ifndef RING_USE_ARR
				tmp_ringP = tmp_ringP->next;
#else
                ringNodeP++;
#endif
            }
            else if(data == '}'){
                cnt = i;
                event.state = RING_OK;
                event.offset = cnt;
                strBuff[i] = 0;
                break;
            }
            else{
#ifndef RING_USE_ARR
                if(tmp_ringP->next == NULL)
#else
                if(ringNodeP == (ringBuffTail + 1)%RING_BUFF_LENGTH )
#endif
                {
                    event.state = RING_WAITFORFLAG;
                    return event;
                }
                event.state = RING_ERR;//cmp next cmd
                return event;
            }
        }
        event.floatData = atof(strBuff);
        if(event.floatData == 0.0){
            event.state = RING_ERR;
        }
        else
            event.state = RING_FLOAT;
        return event;
    }
    event.state = RING_ERR;//cmp next cmd
    return event;
}


